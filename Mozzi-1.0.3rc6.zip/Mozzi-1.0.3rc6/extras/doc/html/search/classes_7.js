var searchData=
[
  ['oscil',['Oscil',['../class_oscil.html',1,'']]],
  ['oscil_3c_208192_2c_20audio_5frate_20_3e',['Oscil&lt; 8192, AUDIO_RATE &gt;',['../class_oscil.html',1,'']]],
  ['oscil_3c_20cos8192_5fnum_5fcells_2c_20audio_5frate_20_3e',['Oscil&lt; COS8192_NUM_CELLS, AUDIO_RATE &gt;',['../class_oscil.html',1,'']]],
  ['oscil_3c_20sin2048_5fnum_5fcells_2c_20audio_5frate_20_3e',['Oscil&lt; SIN2048_NUM_CELLS, AUDIO_RATE &gt;',['../class_oscil.html',1,'']]],
  ['oversample',['OverSample',['../class_over_sample.html',1,'']]]
];
