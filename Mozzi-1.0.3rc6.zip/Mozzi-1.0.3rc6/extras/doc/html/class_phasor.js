var class_phasor =
[
    [ "Phasor", "class_phasor.html#a147c4c3aa7506c3da800e6cc77deb4ac", null ],
    [ "next", "class_phasor.html#a08ab94aeb466450173bd486fbf8eb823", null ],
    [ "phaseIncFromFreq", "class_phasor.html#a9b5992b53fa7e449fec950df00c46230", null ],
    [ "set", "class_phasor.html#a509e4a782a36cb9e913da170d6707421", null ],
    [ "setFreq", "class_phasor.html#afc6106c648bddb5f2f084b8f34216b0f", null ],
    [ "setFreq", "class_phasor.html#a81f1976ebb4a91f66f26674efca52072", null ],
    [ "setPhaseInc", "class_phasor.html#aa3d62bdf762247b2523c0a625caeedd7", null ]
];